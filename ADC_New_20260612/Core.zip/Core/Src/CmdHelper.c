/*
 * CmdHelper.c
 *
 *  Created on: Feb 17, 2022
 *      Author: ITry
 */

#include <string.h>
#include "main.h"
#include "CmdHelper.h"
#include "usart.h"
#include "ads1220.h"
#include "I2CHelper.h"

//一类：系统指令
//二类：串口通讯方式指令
//三类: IIC通讯方式指令
//四类: SPI通讯方式指令
#define TYPE1_GET_VERSION 		0x104
#define TYPE1_GET_ADC	 		0x105
#define TYPE1_SET_VDD			0x106


//閸ヨ桨娆㈢粙瀣碍閻楀牊婀伴崣锟�
const uint8_t FIRMWARE_VERSION[] = { 0x01, 0x01 };

uint16_t cmdType;
uint16_t cmdHead;
uint16_t sendLens;
uint16_t sendTimeout;
uint16_t recvLens;
uint16_t recvTimeout;
uint16_t cmdStartChannel;

#define DATATMP_LENGTH  32
uint8_t dataTmp[DATATMP_LENGTH];
struct structI2CINFO i2cFromPC;
int _i = 0;
int _j = 0;
int _k = 0;
uint16_t _ch = 0;
unsigned int ADC_Value = 0;
extern uint16_t adc_buf[1];
uint16_t channel;


void intToByteArray(uint32_t value, uint16_t *byteArray, int byteCount) {
    for (int i = 0; i < byteCount; i++) {
        // 将整数向右移动8*i位，然后与0xFF进行与操作以获取最低的8位
        byteArray[i] = (value >> (8 * i)) & 0xFF;
    }
}

void ParseSystemCmd(uint16_t *cmd, uint8_t cmd_lens, uint16_t *out, uint16_t out_lens) {
	//format: type_cmdHead_para[N]
	cmdHead = cmd[1];
	switch (cmdHead) {

	case TYPE1_GET_VERSION:
		out[0] = FIRMWARE_VERSION[0];
		out[1] = FIRMWARE_VERSION[1];
		break;
	case TYPE1_GET_ADC:
		ADC_Value = GetAD((uint8_t)cmd[2]);
		intToByteArray(ADC_Value, out, 4);
		break;
	case TYPE1_SET_VDD:
		HAL_GPIO_WritePin(VDD_EN_GPIO_Port, VDD_EN_Pin, cmd[2] == 0xFF ? GPIO_PIN_SET:GPIO_PIN_RESET);
		out[0] =HAL_GPIO_ReadPin(VDD_EN_GPIO_Port, VDD_EN_Pin);
		break;
	}
}

void ParseSerialCmd(uint16_t *cmd, uint8_t cmd_lens, uint16_t *out, uint16_t out_lens) {
	//format: type_channel_sendN_sendTimeout_recvN_recvTimeout_sendPara[N]
	channel = cmd[1];
	sendLens = cmd[2];
	sendTimeout = cmd[3];
	recvLens = cmd[4];
	recvTimeout = cmd[5];
	for (_i = 0; _i < sendLens; _i++) {
		out[_i] = (uint8_t) cmd[6 + _i];
	}

	//transmitString(out, sendLens);//串口透传数据
	if (recvLens > 0) {
		memset(out, 0, out_lens * sizeof(uint8_t));
		//receiveString(out, recvLens, recvTimeout);//串口接收缓存数据
	}
}

void ParseI2CCmd(uint16_t *cmd, uint8_t cmd_lens, uint16_t *out, uint16_t out_lens) {
	//format: type_channel_r/w_busAddr_command_dataLens_datas[N]
	i2cFromPC.channel = cmd[1];
	i2cFromPC.bus_addr = cmd[3];
	i2cFromPC.start_reg = cmd[4];
	i2cFromPC.data_lens = cmd[5];
	if (cmd[2] == 0x11) { //iic_write
		if (i2cFromPC.data_lens < DATATMP_LENGTH) {
			memset(dataTmp, 0, sizeof(dataTmp));
			for (_i = 0; _i < i2cFromPC.data_lens; _i++) {
				dataTmp[_i] = cmd[6 + _i];
			}
			out[0] = I2C_WriteNByte(i2cFromPC, dataTmp);
		} else
			out[0] = 0xF2;
	} else if (cmd[2] == 0x22) { //iic_read
		if (i2cFromPC.data_lens < out_lens) {
			out[i2cFromPC.data_lens] = I2C_ReadNByte(i2cFromPC, out);
		} else
			out[0] = 0xF2;

	} else
		out[0] = 0xFE;
	I2C_IDLE();
}

void ParseSpiCmd(uint16_t *cmd, uint8_t cmd_lens, uint16_t *out, uint16_t out_lens) {

}

void ParseProductCmd(uint16_t *cmd, uint8_t cmd_lens, uint16_t *out, uint16_t out_lens) {

}
/*
 *
 */
void Parse(uint16_t *cmd, uint8_t cmd_lens, uint16_t *out, uint16_t out_lens) {
	cmdType = cmd[0];
	switch (cmdType) {
	case 1:
		ParseSystemCmd(cmd, cmd_lens, out, out_lens);
		break;
	case 2:
		ParseSerialCmd(cmd, cmd_lens, out, out_lens);
		break;
	case 3:
		ParseI2CCmd(cmd, cmd_lens, out, out_lens);
		break;
	case 4:
		ParseSpiCmd(cmd, cmd_lens, out, out_lens);
		break;
	case 5:
		ParseProductCmd(cmd, cmd_lens, out, out_lens);
		break;
	}
}

