/*
 * I2CHelper.c
 *
 *  Created on: 2020年8月4日
 *      Author: ITry
 */
#include <I2CHelper.h>
#include <string.h>

void I2C_IDLE(){
	iic_idle();
}

/*
 * 杩炵画璇籒涓瘎瀛樺櫒鐨勫��
 */
uint8_t I2C_ReadNByte(I2CInfo info, uint16_t *readData) {
	uint8_t i = 0;
	uint8_t err = 0;
	if(info.data_lens > 0) memset(readData, 0, (info.data_lens * sizeof(uint8_t)));

	do {
		iic_start();
		iic_sendbyte(info.bus_addr | IIC_WRITE);
		err = iic_wait_ack();
		if(err) break;
		iic_sendbyte(info.start_reg);
		err = iic_wait_ack();
		if(err) break;
		iic_stop();

		iic_start();
		iic_sendbyte(info.bus_addr | IIC_READ);
		err = iic_wait_ack();
		if(err) break;
		for (i = 0; i < info.data_lens; i++) {
			if (i != (info.data_lens - 1)) {
				readData[i] = iic_readbyte(1); // 璇诲畬闈炴渶鍚庝竴涓瓧鑺傚悗锛� 浜х敓搴旂瓟淇″彿
			} else {
				readData[i] = iic_readbyte(0); // 鏈�鍚庝竴涓瓧鑺傝瀹屽悗 浜х敓闈炲簲绛斾俊鍙�,浠ユ彁绀篠lave璁惧鍑嗗鎺ユ敹Stop淇″彿
			}
		}
	} while (0);
	iic_stop();
	//iic_idle();
	return err;
}

/*
 * 杩炵画鍐橬涓瘎瀛樺櫒鐨勫��
 */
uint8_t I2C_WriteNByte(I2CInfo info, const uint8_t *writeData) {
	uint8_t i = 0;
	uint8_t err = 0;

	do {
		iic_start();
		iic_sendbyte(info.bus_addr | IIC_WRITE);
		err = iic_wait_ack();
		if(err) break;
		iic_sendbyte(info.start_reg);
		err = iic_wait_ack();
		if(err) break;
		while (i < info.data_lens) {
			iic_sendbyte(writeData[i]);
			err = iic_wait_ack();
			if(err) break;
			i++;
		}
	} while (0);
	iic_stop();
	//iic_idle();
	return err;
}
