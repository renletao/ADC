/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "MCP4725.h"

/* USER CODE BEGIN 0 */
#include "SoftIIC.h"
#include "cmsis_os.h"
/* USER CODE END 0 */

/* USER CODE BEGIN 1 */
I2CInfo dac_i2c;
/* USER CODE END 1 */

void MCP4725_Init(void)
{
	IIC_Init(&dac_i2c,DAC_SDA_GPIO_Port, DAC_SDA_Pin, DAC_SCL_GPIO_Port, DAC_SCL_Pin);
	osDelay(10);
	MCP4725_WriteData_Voltage(5000);
}

void MCP4725_WriteData_Voltage(uint16_t Vout)   //��ѹ��λmV
{
  uint8_t data[3];
	uint8_t temp;
	uint16_t Dn;
	Dn = ( 4096 * Vout/2) / VREF_3V3; //�����VREF_3V3�궨��Ϊ3300
	temp = (0x0F00 & Dn) >> 8;  //12λ���ݡ�0000XXXX XXXXXXXX
	data[0] = 0xC0;
	data[1] = temp;  //12λ���ݡ�0000XXXX XXXXXXXX 
	data[2] = Dn; //�����VREF_5V�궨��Ϊ5000
	
	I2C_WriteNByte(&dac_i2c, data,3);

	osDelay(10);	
}

/* USER CODE BEGIN 2 */

/* USER CODE END 2 */
